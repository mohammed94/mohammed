//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GetFileList.rc
//
#define IDD_GETFILELIST_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_CHECK_LOOK_IN_SUBDIRECTORIES 1000
#define IDC_LIST_FILES                  1001
#define IDC_BUTTON_GET_FILE_LIST        1002
#define IDC_EDIT_TARGET_DIRECTORY       1003
#define IDC_BUTTON_BROWSE_DIRECTORY     1004
#define IDC_EDIT_TOTAL_FILES            1005
#define IDC_EDIT_TARGET_DIRECTORY2      1006
#define IDC_EDIT_WILD_CARD              1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
