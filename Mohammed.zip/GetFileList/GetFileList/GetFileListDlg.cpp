// GetFileListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GetFileList.h"
#include "GetFileListDlg.h"

#include "BrowseForFolder.H"
#include "Util.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CGetFileListDlg dialog




CGetFileListDlg::CGetFileListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGetFileListDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGetFileListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_TARGET_DIRECTORY, m_edtTargetDirectory);
	DDX_Control(pDX, IDC_EDIT_WILD_CARD, m_edtWildCard);
	DDX_Control(pDX, IDC_CHECK_LOOK_IN_SUBDIRECTORIES, m_chkLookInSubdirectories);
	DDX_Control(pDX, IDC_LIST_FILES, m_lstFiles);
	DDX_Control(pDX, IDC_EDIT_TOTAL_FILES, m_edtTotalFiles);
}

BEGIN_MESSAGE_MAP(CGetFileListDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_DIRECTORY, &CGetFileListDlg::OnBnClickedButtonBrowseDirectory)
	ON_BN_CLICKED(IDC_BUTTON_GET_FILE_LIST, &CGetFileListDlg::OnBnClickedButtonGetFileList)
END_MESSAGE_MAP()


// CGetFileListDlg message handlers

BOOL CGetFileListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_edtTargetDirectory.SetWindowText(_T("C:\\"));
	m_edtWildCard.SetWindowText(_T("*.*"));

	m_chkLookInSubdirectories.SetCheck(BST_CHECKED);

	m_lstFiles.ResetContent();

	m_edtTotalFiles.SetWindowText(_T("0"));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGetFileListDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGetFileListDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CGetFileListDlg::OnBnClickedButtonBrowseDirectory()
{
	_tstring strDefaultDirectory = _T("C:");

	CString strTargetDirectory = BrowseForFolder(this, _T("Select folder"), strDefaultDirectory.c_str());

	if(strTargetDirectory.CompareNoCase(_T("")) == 0)
	{
		return;
	}

	m_edtTargetDirectory.SetWindowText(strTargetDirectory);
}

void CGetFileListDlg::OnBnClickedButtonGetFileList()
{
	CWaitCursor WaitCursor;

	CString strTargetDirectory = _T("");
	m_edtTargetDirectory.GetWindowText(strTargetDirectory);

	if(strTargetDirectory.CompareNoCase(_T("")) == 0)
	{
		return;
	}

	CString strWildCard = _T("");
	m_edtWildCard.GetWindowText(strWildCard);

	if(strWildCard.CompareNoCase(_T("")) == 0)
	{
		return;
	}

	bool bLookInSubdirectories = (m_chkLookInSubdirectories.GetCheck() == BST_CHECKED);

	vector<_tstring> vecstrFileList;
	vecstrFileList.clear();

	CUtil::GetFileList(_tstring(strTargetDirectory.GetBuffer()), _tstring(strWildCard.GetBuffer()), bLookInSubdirectories, vecstrFileList);

	m_lstFiles.ResetContent();

	long lFileIndex = 0;
	long lFileCount = (long) vecstrFileList.size();

	for(lFileIndex = 0; lFileIndex < lFileCount; lFileIndex++)
	{
		m_lstFiles.AddString(vecstrFileList[lFileIndex].c_str());
	}

	CString strTotalFiles = _T("");
	strTotalFiles.Format(_T("%d"), lFileCount);
	m_edtTotalFiles.SetWindowText(strTotalFiles);
}
